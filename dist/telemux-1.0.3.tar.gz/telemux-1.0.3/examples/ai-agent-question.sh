#!/bin/bash
# AI Agent Asking for Guidance
# Example: Agent encounters uncertainty and asks user for direction
